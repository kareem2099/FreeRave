import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:stream_chat_flutter/stream_chat_flutter.dart';
import 'package:freerave/firebase_options.dart';

import 'auth/screen/login_screen.dart';
import 'main_file_components/app_routes.dart';
import 'main_file_components/bloc_providers.dart';
import 'main_screens/home_screen/public_chat/const.dart';



void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FirebaseAppCheck.instance.activate(
    androidProvider: AndroidProvider.playIntegrity,
  );

  final client = StreamChatClient(
    streamApiKey,
    logLevel: Level.INFO,
  );

  runApp(MyApp(client: client));
}

class MyApp extends StatelessWidget {
  final StreamChatClient client;
  const MyApp({super.key, required this.client});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: getBlocProviders(),
      child: StreamChat(
        client: client,
        child: MaterialApp(
          home: const LoginScreen(),
          routes: getAppRoutes(),
        ),
      ),
    );
  }
}

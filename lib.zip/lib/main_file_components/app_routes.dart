import 'package:flutter/material.dart';
import 'package:freerave/auth/screen/login_screen.dart';
import 'package:freerave/auth/screen/register_screen.dart';
import 'package:freerave/main_screens/main_navigation.dart';

Map<String, WidgetBuilder> getAppRoutes() {
  return {
    '/home': (context) => const MainNavigation(),
    '/login': (context) => const LoginScreen(),
    '/register': (context) => const RegisterScreen(),
  };
}
